!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
DO NOT leave this directory on a site in production. Some scripts within may be
resource intensive and some allow file uploads.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

This directory contains testing scripts and a few example applications built
with the Minify library classes.

tools/
    Two utility web apps that upload a file, alter it, and send it back to the 
    user. One applies HTTP encoding, the other minifies CSS/JS/HTML.
