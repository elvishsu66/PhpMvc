<?php

require 'test_Minify.php';
require 'test_Minify_Build.php';
require 'test_Minify_HTML_Helper.php';
require 'test_Minify_Cache_APC.php';
require 'test_Minify_Cache_File.php';
require 'test_Minify_Cache_Memcache.php';
require 'test_Minify_Cache_ZendPlatform.php';
require 'test_Minify_CSS.php';
require 'test_Minify_CSS_UriRewriter.php';
require 'test_Minify_JS_ClosureCompiler.php';
require 'test_Minify_YuiCSS.php';
require 'test_Minify_CommentPreserver.php';
require 'test_Minify_HTML.php';
require 'test_Minify_ImportProcessor.php';
require 'test_Minify_Lines.php';
require 'test_HTTP_Encoder.php';
require 'test_HTTP_ConditionalGet.php';
require 'test_JSMin.php';
require 'test_environment.php';
